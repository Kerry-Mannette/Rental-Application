package com.example.rental_application;

public class Tools {

    private String toolId;
    private String brand;
    private String model;
    private String year;
    private String color;
    private String RentalRatePerDay;

    public String getToolId() {
        return toolId;
    }

    public void setToolId(String toolId) {
        this.toolId = toolId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getRentalRatePerDay() {
        return RentalRatePerDay;
    }

    public void setRentalRatePerDay(String RentalRatePerDay) {
        this.RentalRatePerDay = RentalRatePerDay;
    }
}
